// StorageAccountListKeysResultTypeProtocol is the response from the ListKeys operation.
protocol StorageAccountListKeysResultTypeProtocol : Codable {
    var keys: [StorageAccountKeyTypeProtocol?]? { get set }
}
