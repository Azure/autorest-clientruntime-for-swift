// ListAccountSasResponseTypeProtocol is the List SAS credentials operation response.
protocol ListAccountSasResponseTypeProtocol : Codable {
    var accountSasToken: String? { get set }
}
