// OperationPropertiesTypeProtocol is properties of operation, include metric specifications.
protocol OperationPropertiesTypeProtocol : Codable {
    var serviceSpecification: ServiceSpecificationTypeProtocol? { get set }
}
