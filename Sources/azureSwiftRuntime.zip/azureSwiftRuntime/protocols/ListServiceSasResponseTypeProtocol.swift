// ListServiceSasResponseTypeProtocol is the List service SAS credentials operation response.
protocol ListServiceSasResponseTypeProtocol : Codable {
    var serviceSasToken: String? { get set }
}
