// UsageListResultTypeProtocol is the response from the List Usages operation.
protocol UsageListResultTypeProtocol : Codable {
    var value: [UsageTypeProtocol?]? { get set }
}
