// VirtualNetworkRuleTypeProtocol is virtual Network rule.
protocol VirtualNetworkRuleTypeProtocol : Codable {
    var id: String? { get set }
    var action: ActionEnum { get set }
    var state: StateEnum { get set }
}
