// StorageSkuListResultTypeProtocol is the response from the List Storage SKUs operation.
protocol StorageSkuListResultTypeProtocol : Codable {
    var value: [SkuTypeProtocol?]? { get set }
}
