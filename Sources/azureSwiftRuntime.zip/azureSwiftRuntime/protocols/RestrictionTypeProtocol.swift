// RestrictionTypeProtocol is the restriction because of which SKU cannot be used.
protocol RestrictionTypeProtocol : Codable {
    var type: String? { get set }
    var values: [String??]? { get set }
    var reasonCode: ReasonCodeEnum { get set }
}
