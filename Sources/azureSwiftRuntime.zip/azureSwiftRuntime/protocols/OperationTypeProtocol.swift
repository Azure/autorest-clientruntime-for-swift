// OperationTypeProtocol is storage REST API operation definition.
protocol OperationTypeProtocol : Codable {
    var name: String? { get set }
    var display: OperationDisplayTypeProtocol? { get set }
    var origin: String? { get set }
    var properties: OperationPropertiesTypeProtocol? { get set }
}
