// StorageAccountListResultTypeProtocol is the response from the List Storage Accounts operation.
protocol StorageAccountListResultTypeProtocol : Codable {
    var value: [StorageAccountTypeProtocol?]? { get set }
}
