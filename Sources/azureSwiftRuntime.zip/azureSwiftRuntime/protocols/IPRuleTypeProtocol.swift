// IPRuleTypeProtocol is IP rule with specific IP or IP range in CIDR format.
protocol IPRuleTypeProtocol : Codable {
    var value: String? { get set }
    var action: ActionEnum { get set }
}
