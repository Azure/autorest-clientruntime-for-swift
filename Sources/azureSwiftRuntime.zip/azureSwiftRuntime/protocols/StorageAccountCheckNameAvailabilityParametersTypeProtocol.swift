// StorageAccountCheckNameAvailabilityParametersTypeProtocol is the parameters used to check the availabity of the
// storage account name.
protocol StorageAccountCheckNameAvailabilityParametersTypeProtocol : Codable {
    var name: String? { get set }
    var type: String? { get set }
}
