struct EncryptionType : EncryptionTypeProtocol {
    var services: EncryptionServicesTypeProtocol?
    var keySource: KeySourceEnum
    var keyvaultproperties: KeyVaultPropertiesTypeProtocol?

    enum CodingKeys: String, CodingKey {
        case services = "services"
        case keySource = "keySource"
        case keyvaultproperties = "keyvaultproperties"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    services = try container.decode(EncryptionServicesType?.self, forKey: .services)
    keySource = try container.decode(KeySourceEnum.self, forKey: .keySource)
    keyvaultproperties = try container.decode(KeyVaultPropertiesType?.self, forKey: .keyvaultproperties)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(services as! EncryptionServicesType?, forKey: .services)
    try container.encode(keySource, forKey: .keySource)
    try container.encode(keyvaultproperties as! KeyVaultPropertiesType?, forKey: .keyvaultproperties)
  }
}
