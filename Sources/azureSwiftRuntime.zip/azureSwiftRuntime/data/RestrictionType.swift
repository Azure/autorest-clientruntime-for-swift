struct RestrictionType : RestrictionTypeProtocol {
    var type: String?
    var values: [String??]?
    var reasonCode: ReasonCodeEnum

    enum CodingKeys: String, CodingKey {
        case type = "type"
        case values = "values"
        case reasonCode = "reasonCode"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    type = try container.decode(String?.self, forKey: .type)
    values = try container.decode([String??]?.self, forKey: .values)
    reasonCode = try container.decode(ReasonCodeEnum.self, forKey: .reasonCode)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(type, forKey: .type)
    try container.encode(values as! [String??]?, forKey: .values)
    try container.encode(reasonCode, forKey: .reasonCode)
  }
}
