struct SkuType : SkuTypeProtocol {
    var name: SkuNameEnum
    var tier: SkuTierEnum
    var resourceType: String?
    var kind: KindEnum
    var locations: [String??]?
    var capabilities: [SKUCapabilityTypeProtocol?]?
    var restrictions: [RestrictionTypeProtocol?]?

    enum CodingKeys: String, CodingKey {
        case name = "name"
        case tier = "tier"
        case resourceType = "resourceType"
        case kind = "kind"
        case locations = "locations"
        case capabilities = "capabilities"
        case restrictions = "restrictions"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    name = try container.decode(SkuNameEnum.self, forKey: .name)
    tier = try container.decode(SkuTierEnum.self, forKey: .tier)
    resourceType = try container.decode(String?.self, forKey: .resourceType)
    kind = try container.decode(KindEnum.self, forKey: .kind)
    locations = try container.decode([String??]?.self, forKey: .locations)
    capabilities = try container.decode([SKUCapabilityType?]?.self, forKey: .capabilities)
    restrictions = try container.decode([RestrictionType?]?.self, forKey: .restrictions)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(name, forKey: .name)
    try container.encode(tier, forKey: .tier)
    try container.encode(resourceType, forKey: .resourceType)
    try container.encode(kind, forKey: .kind)
    try container.encode(locations as! [String??]?, forKey: .locations)
    try container.encode(capabilities as! [SKUCapabilityType?]?, forKey: .capabilities)
    try container.encode(restrictions as! [RestrictionType?]?, forKey: .restrictions)
  }
}
