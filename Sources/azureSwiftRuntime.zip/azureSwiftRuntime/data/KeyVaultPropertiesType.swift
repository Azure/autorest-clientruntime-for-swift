struct KeyVaultPropertiesType : KeyVaultPropertiesTypeProtocol {
    var keyname: String?
    var keyversion: String?
    var keyvaulturi: String?

    enum CodingKeys: String, CodingKey {
        case keyname = "keyname"
        case keyversion = "keyversion"
        case keyvaulturi = "keyvaulturi"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    keyname = try container.decode(String?.self, forKey: .keyname)
    keyversion = try container.decode(String?.self, forKey: .keyversion)
    keyvaulturi = try container.decode(String?.self, forKey: .keyvaulturi)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(keyname, forKey: .keyname)
    try container.encode(keyversion, forKey: .keyversion)
    try container.encode(keyvaulturi, forKey: .keyvaulturi)
  }
}
