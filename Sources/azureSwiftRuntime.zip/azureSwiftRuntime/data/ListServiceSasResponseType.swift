struct ListServiceSasResponseType : ListServiceSasResponseTypeProtocol {
    var serviceSasToken: String?

    enum CodingKeys: String, CodingKey {
        case serviceSasToken = "serviceSasToken"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    serviceSasToken = try container.decode(String?.self, forKey: .serviceSasToken)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(serviceSasToken, forKey: .serviceSasToken)
  }
}
