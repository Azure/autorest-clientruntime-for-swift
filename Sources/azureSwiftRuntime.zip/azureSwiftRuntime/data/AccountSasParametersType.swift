struct AccountSasParametersType : AccountSasParametersTypeProtocol {
    var signedServices: ServicesEnum
    var signedResourceTypes: SignedResourceTypesEnum
    var signedPermission: PermissionsEnum
    var signedIp: String?
    var signedProtocol: HttpProtocolEnum
    var signedStart: Int32?
    var signedExpiry: Int32?
    var keyToSign: String?

    enum CodingKeys: String, CodingKey {
        case signedServices = "signedServices"
        case signedResourceTypes = "signedResourceTypes"
        case signedPermission = "signedPermission"
        case signedIp = "signedIp"
        case signedProtocol = "signedProtocol"
        case signedStart = "signedStart"
        case signedExpiry = "signedExpiry"
        case keyToSign = "keyToSign"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    signedServices = try container.decode(ServicesEnum.self, forKey: .signedServices)
    signedResourceTypes = try container.decode(SignedResourceTypesEnum.self, forKey: .signedResourceTypes)
    signedPermission = try container.decode(PermissionsEnum.self, forKey: .signedPermission)
    signedIp = try container.decode(String?.self, forKey: .signedIp)
    signedProtocol = try container.decode(HttpProtocolEnum.self, forKey: .signedProtocol)
    signedStart = try container.decode(Int32?.self, forKey: .signedStart)
    signedExpiry = try container.decode(Int32?.self, forKey: .signedExpiry)
    keyToSign = try container.decode(String?.self, forKey: .keyToSign)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(signedServices, forKey: .signedServices)
    try container.encode(signedResourceTypes, forKey: .signedResourceTypes)
    try container.encode(signedPermission, forKey: .signedPermission)
    try container.encode(signedIp, forKey: .signedIp)
    try container.encode(signedProtocol, forKey: .signedProtocol)
    try container.encode(signedStart, forKey: .signedStart)
    try container.encode(signedExpiry, forKey: .signedExpiry)
    try container.encode(keyToSign, forKey: .keyToSign)
  }
}
