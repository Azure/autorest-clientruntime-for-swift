struct StorageAccountKeyType : StorageAccountKeyTypeProtocol {
    var keyName: String?
    var value: String?
    var permissions: KeyPermissionEnum

    enum CodingKeys: String, CodingKey {
        case keyName = "keyName"
        case value = "value"
        case permissions = "permissions"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    keyName = try container.decode(String?.self, forKey: .keyName)
    value = try container.decode(String?.self, forKey: .value)
    permissions = try container.decode(KeyPermissionEnum.self, forKey: .permissions)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(keyName, forKey: .keyName)
    try container.encode(value, forKey: .value)
    try container.encode(permissions, forKey: .permissions)
  }
}
