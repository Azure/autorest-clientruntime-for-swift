struct CheckNameAvailabilityResultType : CheckNameAvailabilityResultTypeProtocol {
    var nameAvailable: Bool?
    var reason: ReasonEnum
    var message: String?

    enum CodingKeys: String, CodingKey {
        case nameAvailable = "nameAvailable"
        case reason = "reason"
        case message = "message"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    nameAvailable = try container.decode(Bool?.self, forKey: .nameAvailable)
    reason = try container.decode(ReasonEnum.self, forKey: .reason)
    message = try container.decode(String?.self, forKey: .message)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(nameAvailable, forKey: .nameAvailable)
    try container.encode(reason, forKey: .reason)
    try container.encode(message, forKey: .message)
  }
}
