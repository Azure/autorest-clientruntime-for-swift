struct VirtualNetworkRuleType : VirtualNetworkRuleTypeProtocol {
    var id: String?
    var action: ActionEnum
    var state: StateEnum

    enum CodingKeys: String, CodingKey {
        case id = "id"
        case action = "action"
        case state = "state"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    id = try container.decode(String?.self, forKey: .id)
    action = try container.decode(ActionEnum.self, forKey: .action)
    state = try container.decode(StateEnum.self, forKey: .state)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(id, forKey: .id)
    try container.encode(action, forKey: .action)
    try container.encode(state, forKey: .state)
  }
}
