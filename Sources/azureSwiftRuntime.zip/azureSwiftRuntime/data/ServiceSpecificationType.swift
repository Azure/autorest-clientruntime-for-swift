struct ServiceSpecificationType : ServiceSpecificationTypeProtocol {
    var metricSpecifications: [MetricSpecificationTypeProtocol?]?

    enum CodingKeys: String, CodingKey {
        case metricSpecifications = "metricSpecifications"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    metricSpecifications = try container.decode([MetricSpecificationType?]?.self, forKey: .metricSpecifications)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(metricSpecifications as! [MetricSpecificationType?]?, forKey: .metricSpecifications)
  }
}
