struct IPRuleType : IPRuleTypeProtocol {
    var value: String?
    var action: ActionEnum

    enum CodingKeys: String, CodingKey {
        case value = "value"
        case action = "action"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    value = try container.decode(String?.self, forKey: .value)
    action = try container.decode(ActionEnum.self, forKey: .action)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(value, forKey: .value)
    try container.encode(action, forKey: .action)
  }
}
