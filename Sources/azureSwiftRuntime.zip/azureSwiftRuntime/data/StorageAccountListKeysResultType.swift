struct StorageAccountListKeysResultType : StorageAccountListKeysResultTypeProtocol {
    var keys: [StorageAccountKeyTypeProtocol?]?

    enum CodingKeys: String, CodingKey {
        case keys = "keys"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    keys = try container.decode([StorageAccountKeyType?]?.self, forKey: .keys)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(keys as! [StorageAccountKeyType?]?, forKey: .keys)
  }
}
