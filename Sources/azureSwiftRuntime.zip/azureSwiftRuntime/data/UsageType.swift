struct UsageType : UsageTypeProtocol {
    var unit: UsageUnitEnum
    var currentValue: Int32?
    var limit: Int32?
    var name: UsageNameTypeProtocol?

    enum CodingKeys: String, CodingKey {
        case unit = "unit"
        case currentValue = "currentValue"
        case limit = "limit"
        case name = "name"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    unit = try container.decode(UsageUnitEnum.self, forKey: .unit)
    currentValue = try container.decode(Int32?.self, forKey: .currentValue)
    limit = try container.decode(Int32?.self, forKey: .limit)
    name = try container.decode(UsageNameType?.self, forKey: .name)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(unit, forKey: .unit)
    try container.encode(currentValue, forKey: .currentValue)
    try container.encode(limit, forKey: .limit)
    try container.encode(name as! UsageNameType?, forKey: .name)
  }
}
