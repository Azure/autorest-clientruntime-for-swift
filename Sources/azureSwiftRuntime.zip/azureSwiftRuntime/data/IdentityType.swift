struct IdentityType : IdentityTypeProtocol {
    var principalId: String?
    var tenantId: String?
    var type: String?

    enum CodingKeys: String, CodingKey {
        case principalId = "principalId"
        case tenantId = "tenantId"
        case type = "type"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    principalId = try container.decode(String?.self, forKey: .principalId)
    tenantId = try container.decode(String?.self, forKey: .tenantId)
    type = try container.decode(String?.self, forKey: .type)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(principalId, forKey: .principalId)
    try container.encode(tenantId, forKey: .tenantId)
    try container.encode(type, forKey: .type)
  }
}
