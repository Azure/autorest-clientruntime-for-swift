// ActionEnum enumerates the values for action enum.

enum ActionEnum: String, Codable
{
// Allow specifies the allow state for action enum.
    case Allow = "Allow"
}
