struct DimensionType : DimensionTypeProtocol {
    var name: String?
    var displayName: String?

    enum CodingKeys: String, CodingKey {
        case name = "name"
        case displayName = "displayName"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    name = try container.decode(String?.self, forKey: .name)
    displayName = try container.decode(String?.self, forKey: .displayName)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(name, forKey: .name)
    try container.encode(displayName, forKey: .displayName)
  }
}
