struct UsageNameType : UsageNameTypeProtocol {
    var value: String?
    var localizedValue: String?

    enum CodingKeys: String, CodingKey {
        case value = "value"
        case localizedValue = "localizedValue"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    value = try container.decode(String?.self, forKey: .value)
    localizedValue = try container.decode(String?.self, forKey: .localizedValue)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(value, forKey: .value)
    try container.encode(localizedValue, forKey: .localizedValue)
  }
}
