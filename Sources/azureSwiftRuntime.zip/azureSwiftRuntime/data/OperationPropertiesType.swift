struct OperationPropertiesType : OperationPropertiesTypeProtocol {
    var serviceSpecification: ServiceSpecificationTypeProtocol?

    enum CodingKeys: String, CodingKey {
        case serviceSpecification = "serviceSpecification"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    serviceSpecification = try container.decode(ServiceSpecificationType?.self, forKey: .serviceSpecification)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(serviceSpecification as! ServiceSpecificationType?, forKey: .serviceSpecification)
  }
}
