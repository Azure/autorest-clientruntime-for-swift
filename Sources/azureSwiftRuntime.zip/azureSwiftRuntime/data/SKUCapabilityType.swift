struct SKUCapabilityType : SKUCapabilityTypeProtocol {
    var name: String?
    var value: String?

    enum CodingKeys: String, CodingKey {
        case name = "name"
        case value = "value"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    name = try container.decode(String?.self, forKey: .name)
    value = try container.decode(String?.self, forKey: .value)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(name, forKey: .name)
    try container.encode(value, forKey: .value)
  }
}
