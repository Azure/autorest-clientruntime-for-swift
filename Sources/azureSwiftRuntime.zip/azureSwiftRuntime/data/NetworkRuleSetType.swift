struct NetworkRuleSetType : NetworkRuleSetTypeProtocol {
    var bypass: BypassEnum
    var virtualNetworkRules: [VirtualNetworkRuleTypeProtocol?]?
    var ipRules: [IPRuleTypeProtocol?]?
    var defaultAction: DefaultActionEnum

    enum CodingKeys: String, CodingKey {
        case bypass = "bypass"
        case virtualNetworkRules = "virtualNetworkRules"
        case ipRules = "ipRules"
        case defaultAction = "defaultAction"
    }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)
    bypass = try container.decode(BypassEnum.self, forKey: .bypass)
    virtualNetworkRules = try container.decode([VirtualNetworkRuleType?]?.self, forKey: .virtualNetworkRules)
    ipRules = try container.decode([IPRuleType?]?.self, forKey: .ipRules)
    defaultAction = try container.decode(DefaultActionEnum.self, forKey: .defaultAction)
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.container(keyedBy: CodingKeys.self)
    try container.encode(bypass, forKey: .bypass)
    try container.encode(virtualNetworkRules as! [VirtualNetworkRuleType?]?, forKey: .virtualNetworkRules)
    try container.encode(ipRules as! [IPRuleType?]?, forKey: .ipRules)
    try container.encode(defaultAction, forKey: .defaultAction)
  }
}
