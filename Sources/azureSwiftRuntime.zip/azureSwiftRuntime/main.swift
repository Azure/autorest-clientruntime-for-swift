//
//  main.swift
//  azureSwiftRuntime
//
//  Created by Vladimir Shcherbakov on 11/3/17.
//

import Foundation


//let filepath = "/Users/vlashch/__sp/json.azureauth"
//do {
//    let atc: ServiceClientCredential = try ApplicationTokenCredentials.fromFile(path: filepath)
//    let token = try atc.authHeaderValue(url: nil)
//    
//} catch {
//    print(error)
//}

